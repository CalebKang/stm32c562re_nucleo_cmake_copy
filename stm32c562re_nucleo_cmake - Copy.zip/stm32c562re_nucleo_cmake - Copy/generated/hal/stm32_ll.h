/**
  ******************************************************************************
  * @file    stm32_ll.h
  * @brief   This file contains all the functions prototypes for the LL
  *          module driver, whatever the STM32 family.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the mx_stm32c5xx_hal_drivers_license.md file
  * in the same directory as the generated code.
  * If no mx_stm32c5xx_hal_drivers_license.md file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef STM32_LL_H
#define STM32_LL_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32c5xx_ll_adc.h"
#include "stm32c5xx_ll_bus.h"
#include "stm32c5xx_ll_dma.h"
#include "stm32c5xx_ll_exti.h"
#include "stm32c5xx_ll_flash.h"
#include "stm32c5xx_ll_gpio.h"
#include "stm32c5xx_ll_i2c.h"
#include "stm32c5xx_ll_icache.h"
#include "stm32c5xx_ll_pwr.h"
#include "stm32c5xx_ll_rcc.h"
#include "stm32c5xx_ll_sbs.h"
#include "stm32c5xx_ll_tim.h"
#include "stm32c5xx_ll_usart.h"
#include "stm32c5xx_ll_utils.h"

/* Exported variables --------------------------------------------------------*/
/* Exported functions --------------------------------------------------------*/
/* Private types -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private constants ---------------------------------------------------------*/
/* Private macros ------------------------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* STM32_LL_H */
