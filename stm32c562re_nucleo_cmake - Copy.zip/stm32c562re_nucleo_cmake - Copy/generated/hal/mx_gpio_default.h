/**
  ******************************************************************************
  * @file           : mx_gpio_default.h
  * @brief          : Header for mx_gpio_default.c file.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the mx_stm32c5xx_hal_drivers_license.md file
  * in the same directory as the generated code.
  * If no mx_stm32c5xx_hal_drivers_license.md file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MX_GPIO_DEFAULT_H
#define MX_GPIO_DEFAULT_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Includes ------------------------------------------------------------------*/
#include "stm32_ll.h"
#include "mx_def.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/******************************************************************************/
/* Exported defines for gpio_default in LL layer (SW instance MyGPIO_1) */
/******************************************************************************/

/* Primary aliases for GPIO PA15(JTDI) pin */
#define TEST_TIM_CC_PORT                                GPIOA
#define TEST_TIM_CC_PIN                                 LL_GPIO_PIN_15

/* Primary aliases for GPIO PC10 pin */
#define TEST_DMA_TC_PORT                                GPIOC
#define TEST_DMA_TC_PIN                                 LL_GPIO_PIN_10
#define TEST_DMA_TC_INIT_STATE                          LL_GPIO_PIN_RESET
#define TEST_DMA_TC_ACTIVE_STATE                        LL_GPIO_PIN_SET
#define TEST_DMA_TC_INACTIVE_STATE                      LL_GPIO_PIN_RESET

/* Primary aliases for GPIO PC11 pin */
#define SHUT_PORT                                       GPIOC
#define SHUT_PIN                                        LL_GPIO_PIN_11
#define SHUT_INIT_STATE                                 LL_GPIO_PIN_RESET
#define SHUT_ACTIVE_STATE                               LL_GPIO_PIN_SET
#define SHUT_INACTIVE_STATE                             LL_GPIO_PIN_RESET

/* Primary aliases for GPIO PC12 pin */
#define INT_PORT                                        GPIOC
#define INT_PIN                                         LL_GPIO_PIN_12
#define INT_INIT_STATE                                  LL_GPIO_PIN_RESET
#define INT_ACTIVE_STATE                                LL_GPIO_PIN_SET
#define INT_INACTIVE_STATE                              LL_GPIO_PIN_RESET

/* Exported macros -----------------------------------------------------------*/
/* Exported variables --------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
/******************************************************************************/
/* Exported functions for gpio_default in LL layer (SW instance MyGPIO_1) */
/******************************************************************************/
/**
  * @brief mx_gpio_default init function
  * This function configures the hardware resources used in this example
  * @retval 0  GPIO group correctly initialized
  * @retval -1 Issue detected during GPIO group initialization
  */
system_status_t mx_gpio_default_init(void);

/**
  * @brief  De-initialize gpio_default instance.
  */
system_status_t mx_gpio_default_deinit(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* MX_GPIO_DEFAULT_H */
